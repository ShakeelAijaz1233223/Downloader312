# Notes

- Filename and MIME type come from trusted server metadata.
- Large files are streamed with HTTP Range support.
