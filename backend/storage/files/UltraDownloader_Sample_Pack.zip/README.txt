UltraDownloader - Authorized Sample ZIP
=======================================
This archive is served by the secure download endpoint and is a real,
extractable ZIP file (not a renamed file).

Contents:
  README.txt
  sample-data/links.csv
  sample-data/notes.md

Verify: the file starts with 'PK\x03\x04' and extracts in Windows Explorer.
